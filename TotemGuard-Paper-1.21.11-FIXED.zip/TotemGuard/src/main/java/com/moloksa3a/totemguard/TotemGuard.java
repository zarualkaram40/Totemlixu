package com.moloksa3a.totemguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TotemGuard extends JavaPlugin implements Listener {
    private static final String GUI_TITLE = "TotemGuard | Players";

    // These counters intentionally track the current online session only.
    private final Map<UUID, Integer> pops = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastSwap = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> fastSwaps = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> flags = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastFlag = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<Long>> swapHistory = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("TotemGuard enabled for Paper 1.21.11");
    }

    @EventHandler
    public void onPop(EntityResurrectEvent event) {
        if (event.getEntity() instanceof Player player) {
            pops.merge(player.getUniqueId(), 1, Integer::sum);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent event) {
        checkSwap(event.getPlayer());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Handle our GUI first, so clicking a head never counts as an offhand swap.
        if (isTotemGuardGui(event.getView().getTitle())) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || clicked.getType() != Material.PLAYER_HEAD) return;
            if (!(clicked.getItemMeta() instanceof SkullMeta meta)) return;
            OfflinePlayer target = meta.getOwningPlayer();
            if (target != null) showPlayer(player, target);
            return;
        }

        // Slot 40 is the offhand slot in the player's own inventory.
        if (event.getClickedInventory() == player.getInventory() && event.getSlot() == 40) {
            checkSwap(player);
        }
    }

    private boolean isTotemGuardGui(String title) {
        return ChatColor.stripColor(title).equals(GUI_TITLE);
    }

    private void checkSwap(Player player) {
        if (!player.getInventory().contains(Material.TOTEM_OF_UNDYING)) return;

        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();
        long previous = lastSwap.getOrDefault(id, 0L);
        long fastWindow = Math.max(50L, getConfig().getLong("detection.fast-window-ms", 450L));

        if (previous > 0L && now - previous <= fastWindow) {
            fastSwaps.merge(id, 1, Integer::sum);
            Deque<Long> history = swapHistory.computeIfAbsent(id, ignored -> new ArrayDeque<>());
            synchronized (history) {
                history.addLast(now);
                while (!history.isEmpty() && now - history.peekFirst() > 10_000L) {
                    history.removeFirst();
                }

                int threshold = Math.max(2, getConfig().getInt("detection.flag-after-fast-swaps", 8));
                long cooldown = Math.max(1_000L, getConfig().getLong("detection.flag-cooldown-ms", 15_000L));
                if (history.size() >= threshold && now - lastFlag.getOrDefault(id, 0L) >= cooldown) {
                    flags.merge(id, 1, Integer::sum);
                    lastFlag.put(id, now);
                    alertStaff(player, id);
                }
            }
        }
        lastSwap.put(id, now);
    }

    private void alertStaff(Player suspected, UUID id) {
        String message = color("&c[TotemGuard] &f" + suspected.getName()
                + " &7has suspicious rapid totem swaps (&c" + flags.getOrDefault(id, 0)
                + " flags&7). &8(Not proof of cheating)");
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("totemguard.alerts")) staff.sendMessage(message);
        }
        if (getConfig().getBoolean("messages.notify-player", true)) {
            suspected.sendMessage(color("&c[TotemGuard] &7Rapid offhand changes detected. This is suspicion only, not proof of AutoTotem."));
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("totempop")) {
            if (args.length > 0 && !sender.hasPermission("totemguard.pop.others")) {
                sender.sendMessage(color("&cYou do not have permission to check other players."));
                return true;
            }
            OfflinePlayer target;
            if (args.length > 0) {
                target = Bukkit.getOfflinePlayer(args[0]);
            } else if (sender instanceof Player player) {
                target = player;
            } else {
                sender.sendMessage(color("&cUsage: /totempop <player>"));
                return true;
            }
            int count = pops.getOrDefault(target.getUniqueId(), 0);
            sender.sendMessage(color("&6[TotemGuard] &f" + safeName(target) + " &7has &e" + count + " &7totem pops this session."));
            return true;
        }

        if (cmd.equals("totemcheck")) {
            if (!sender.hasPermission("totemguard.check")) {
                sender.sendMessage(color("&cYou do not have permission."));
                return true;
            }
            if (args.length > 0) {
                showPlayer(sender, Bukkit.getOfflinePlayer(args[0]));
                return true;
            }
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color("&cUsage: /totemcheck <player> from console."));
                return true;
            }
            openGui(player);
            return true;
        }
        return false;
    }

    private String safeName(OfflinePlayer player) {
        String name = player.getName();
        return name == null ? "Unknown" : name;
    }

    private void showPlayer(CommandSender sender, OfflinePlayer target) {
        UUID id = target.getUniqueId();
        sender.sendMessage(color("&6&m--------&r &eTotemGuard: " + safeName(target) + " &6&m--------"));
        sender.sendMessage(color("&7Totem Pops: &e" + pops.getOrDefault(id, 0)));
        sender.sendMessage(color("&7Fast swaps: &e" + fastSwaps.getOrDefault(id, 0)));
        sender.sendMessage(color("&7Suspicion flags: &c" + flags.getOrDefault(id, 0)));
        sender.sendMessage(color("&8Detection is heuristic; manual review is recommended."));
    }

    private void openGui(Player viewer) {
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        int size = Math.max(9, Math.min(54, ((online.size() + 8) / 9) * 9));
        Inventory inventory = Bukkit.createInventory(null, size, color("&8" + GUI_TITLE));
        for (Player target : online) {
            ItemStack item = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) item.getItemMeta();
            if (meta == null) continue;
            meta.setOwningPlayer(target);
            meta.setDisplayName(color("&e" + target.getName()));
            List<String> lore = new ArrayList<>();
            lore.add(color("&7Totem Pops: &e" + pops.getOrDefault(target.getUniqueId(), 0)));
            lore.add(color("&7Fast swaps: &e" + fastSwaps.getOrDefault(target.getUniqueId(), 0)));
            lore.add(color("&7Flags: &c" + flags.getOrDefault(target.getUniqueId(), 0)));
            lore.add(color("&8Click for details"));
            meta.setLore(lore);
            item.setItemMeta(meta);
            inventory.addItem(item);
        }
        viewer.openInventory(inventory);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        pops.remove(id);
        lastSwap.remove(id);
        fastSwaps.remove(id);
        flags.remove(id);
        lastFlag.remove(id);
        swapHistory.remove(id);
    }

    private String color(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
}
