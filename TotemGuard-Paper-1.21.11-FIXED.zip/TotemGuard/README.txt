TotemGuard - Paper 1.21.11

Requirements:
- Paper 1.21.11
- Java 21

Build:
  mvn clean package

The output JAR is created in target/.
Install:
1. Copy target/TotemGuard-1.0.1.jar into the server's plugins folder.
2. Start the server once to generate plugins/TotemGuard/config.yml.
3. Restart after changing the config if needed.

Commands:
- /totempop [player] - shows totem pops this session. Checking another player requires totemguard.pop.others.
- /totemcheck [player] - opens the online-player GUI or prints a player's session statistics. Requires totemguard.check.

Permissions:
- totemguard.check (default: op)
- totemguard.alerts (default: op)
- totemguard.pop.others (default: op)

Important:
- Statistics are session-only and reset when a player disconnects or the server restarts.
- Rapid offhand swapping is only a heuristic. It can produce false positives and is not proof of AutoTotem or cheating. Do not use flags alone for punishment.
